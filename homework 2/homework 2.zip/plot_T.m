function plot_T(T)
rot = T(1:3, 1:3)
pos = T(1:3, 4)


end

